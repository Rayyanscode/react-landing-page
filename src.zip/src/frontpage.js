import React from "react";
import bootstrap from "bootstrap";
import img1 from './pic/img1.png';
import img2 from './pic/img2.png';
import star from './pic/star.svg';
import circle from './pic/circle.svg';
import heart from './pic/heart.svg';
import './style.css';

function Front() {
    return (
        <div class="container">
            <div class="row">
                <div class="col-2"><img className="one" src={img1} height="500px" alt="" /></div>
                <div class="col-4"><img className="two" src={img2} height="500px" alt="" /></div>
                <div class="col-4">
                    <h1 className="heading">Leather jacket</h1>
                    <button class="bat">Men</button>
                    <p className="icon"><img src={star} height="20px" alt="" />
                        <img src={star} height="20px" alt="" />
                        <img src={star} height="20px" alt="" />
                        <img src={star} height="20px" alt="" /></p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id ab doloremque repellendus vero nam est fuga iusto, optio explicabo reiciendis esse soluta alias ut a. Similique vitae tempora dolores fuga.</p>
                    <ul className="list">
                        <li>price:</li>
                        <li>color:</li>
                        <li>size:</li>
                    </ul>
                    <ul className="list2">
                        <li>$117.99</li>
                        <li class="main"> <img src={circle} height="20px" alt="" />  <img src={circle} height="20px" alt="" />  <img src={circle} height="20px" alt="" />  </li>
                        <li>S M L XL</li>
                    </ul>
                    <ul className="list3">
                        <li><button class="bn">-</button><button class="bn">2</button><button class="bn">+</button></li>
                        <li> <button class="bn">ADD TO CART</button></li>
                        <li> <img src={heart} height="20px" alt="" /></li>
                    </ul>
                </div>                
            </div>

        </div>
    )

}

export default Front;
