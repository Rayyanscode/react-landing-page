import logo from './logo.svg';
import './App.css';
import Front from './frontpage';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";



function App() {
  return (
    // <div className="App">
      <Front />
    /* </div> */
  );
}

export default App;
